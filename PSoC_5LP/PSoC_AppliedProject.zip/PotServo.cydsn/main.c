// Description:
// This program is used with a button, potentiometer, servo, solenoid, and LCD screen.
// When the user turns the potentiometer, the servo will move to a corresponding angle.
// The angle value will be printed on the LCD screen.
// When the user presses the button, the solenoid will activate.
// As soon as the user depresses the button the solenoid will turn off.
// This system can be used with the corresponding hardware to pick up a ferromagnetic nut
// within a limited path set by the length of the links on the robotic arm.

#include "project.h"
#include "math.h"
#include "stdio.h"

// Based on the adcValue, determine the angle
int angle1(int adcValue){
    
    int MIN = 0;
    int MAX = 180;
    
    if(adcValue == 0){
        return MIN;
    }
    else if(adcValue == 4095){
        return MAX;
    }
    else{
        return MIN + adcValue * ((float)(MAX - MIN) / 4096);
    }
}

// Based on the adcValue, determine the number of ticks for PWM
int adc_ticks(int adcValue){
    
    int PULSE_MIN = 2000;
    int PULSE_MAX = 11500;
    
    if(adcValue == 0){
        return PULSE_MIN;
        }
    else if(adcValue == 4096){
        return PULSE_MAX;
    }
    else{
        return PULSE_MIN + adcValue * ((PULSE_MAX - PULSE_MIN) / 4096);
    }
}

// Main function used to initialize modules and execute main for loop
int main(void)
{
    // Start modules
    CyGlobalIntEnable;
    PWM_Start();
    ADC_Start();
    ADC_StartConvert();
    UART_Start();
    LCD_Start();

    // Initialize variables
    uint16 x;           // uint16 to store the analog potentiometer value
    char string[10];    // Character array to store the angle value to print

    
    for(;;)
    {
        // Read analog value from potentiometer
        ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
        x = ADC_GetResult16();
        
        // Write the pwm value
        PWM_WriteCompare(adc_ticks(x));
        
        // Convert angle value to string and print to LCD
        LCD_ClearDisplay();
        LCD_Position(0,0);
        sprintf(string, "%i, %i\n", angle1(x), x);
        LCD_PrintNumber(angle1(x));
        
        // Print angle value to UART (Putty) as well (debug)
        UART_PutString(string);
        CyDelay(100);
        
        // Read the button value and write it to the solenoid
        // - if button pressed, solenoid is on
        Solenoid_Write(Button_Read());
        CyDelay(500);
    }
}
